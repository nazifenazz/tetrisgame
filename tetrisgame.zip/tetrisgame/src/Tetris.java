import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Tetris {
    int[][] dizi = new int[20][11];
    static int h = 0;
    SatirSil silici = new SatirSil();

    public void init() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 11; j++) dizi[i][j] = 0;
        }
    }

    public HareketSekilleri rastgeleSekilGetir() {
        Random r = new Random();
        int secim = r.nextInt(5);
        if (secim == 0) return new Kare();
        else if (secim == 1) return new Cubuk();
        else if (secim == 2) return new LHarfi();
        else if (secim == 3) return new ZHarfi();
        else return new Ucgen();
    }

    public void ekranaYazdir() throws IOException {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        for (int i = 0; i < 20; i++) {
            System.out.print("I");
            for (int j = 0; j < 11; j++) {
                if (dizi[i][j] == 0) System.out.print("  ");
                else System.out.print("[]");
            }
            System.out.println("I");
        }
        System.out.println("------------------------");
    }

    // Şekil bu satır/sütun konumuna gelirse çarpışır mı bakıyoruz
    public boolean uygunMu(HareketSekilleri s, int yeniSatir, int yeniSutun) {
        int eskiSatir = s.satir;// eski konumları saklıyoruz
        int eskiSutun = s.sutun;

        s.satir = yeniSatir;//Şekli geçici olarak yeni yere koyduk
        s.sutun = yeniSutun;

        int[][] h = s.hucreler();//şeklin 4 bloğunun koordinatı
        for (int i = 0; i < 4; i++) {
            int r = h[i][0];
            int c = h[i][1];

            if (r < 0 || r >= 20 || c < 0 || c >= 11) {//şeklin dışına tastı mı
                s.satir = eskiSatir; s.sutun = eskiSutun;
                return false;
            }
            if (dizi[r][c] == 1) {//Orada başka blok var mı bakar
                s.satir = eskiSatir; s.sutun = eskiSutun;
                return false;
            }
        }

        s.satir = eskiSatir;//sorun yoksa eski yerine geri koy ve true dön
        s.sutun = eskiSutun;
        return true;
    }

    public void hareketEt(HareketSekilleri s, int ds, int dc) {
        s.sekliSil(dizi);
        if (uygunMu(s, s.satir + ds, s.sutun + dc)) {//Şekli gitmek istediği yeni koordinatlara  hayali olarak gönderip test ediyor
            s.satir += ds;//yol temizse koordinatları gerçekten güncelliyor
            s.sutun += dc;
        }
        s.sekliCiz(dizi);
    }

    public void dondurDene(HareketSekilleri s) {
        s.sekliSil(dizi);

        int eskiDurum = s.getDurum();//Şeklin eski yönünü saklıyoruz

        s.dondur(dizi);

        // döndükten sonra  uygunsa bırak değilse geri al
        if (!uygunMu(s, s.satir, s.sutun)) {
            s.setDurum(eskiDurum);
        }

        s.sekliCiz(dizi);
    }

    public void metotBaslat() throws InterruptedException, IOException {
        init();

        JFrame f = new JFrame("Kontrol");
        f.setSize(200, 100);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) h = -1;
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) h = 1;
                if (e.getKeyCode() == KeyEvent.VK_UP) h = 2;// döndürme için
            }
        });
        f.setVisible(true);

        HareketSekilleri mevcutSekil = rastgeleSekilGetir();


        if (!uygunMu(mevcutSekil, mevcutSekil.satir, mevcutSekil.sutun)) {
            System.out.println("Oyun Bitti!");
            return;
        }
        mevcutSekil.sekliCiz(dizi);
        ekranaYazdir();

        while (true) {

            if (h == -1) { hareketEt(mevcutSekil, 0, -1); h = 0; }
            else if (h == 1) { hareketEt(mevcutSekil, 0, 1); h = 0; }



            else if (h == 2) { dondurDene(mevcutSekil); h = 0; }


            mevcutSekil.sekliSil(dizi);

            if (uygunMu(mevcutSekil, mevcutSekil.satir + 1, mevcutSekil.sutun)) {
                mevcutSekil.satir++;
                mevcutSekil.sekliCiz(dizi);
            } else {

                mevcutSekil.sekliCiz(dizi);
                silici.satirSilme(dizi);


                mevcutSekil = rastgeleSekilGetir();
                if (!uygunMu(mevcutSekil, mevcutSekil.satir, mevcutSekil.sutun)) {
                    ekranaYazdir();
                    System.out.println("Oyun Bitti!");
                    break;
                }
                mevcutSekil.sekliCiz(dizi);
            }

            ekranaYazdir();
            TimeUnit.MILLISECONDS.sleep(200);
        }
    }
}
