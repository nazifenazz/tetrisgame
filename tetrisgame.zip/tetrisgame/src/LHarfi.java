public class LHarfi extends HareketSekilleri {
    private int durum = 0; // 0 ve 1 (iki durumlu L)

    @Override public int getDurum() { return durum; }
    @Override public void setDurum(int d) { durum = d; }

    @Override
    public int[][] hucreler() {
        if (durum == 0) { //normal L
            return new int[][]{
                    {satir, sutun},
                    {satir+1, sutun},
                    {satir+2, sutun},
                    {satir+2, sutun+1}
            };
        } else {
            return new int[][]{
                    {satir, sutun},
                    {satir+1, sutun},
                    {satir+1, sutun+1},
                    {satir+1, sutun+2}
            };
        }
    }

    @Override
    public void sekliCiz(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 1;
    }

    @Override
    public void sekliSil(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 0;
    }

    @Override
    public void dondur(int[][] dizi) {
        durum = (durum + 1) % 2;
    }

    @Override
    public boolean altDoluMu(int[][] dizi) {

        return false;
    }
}
