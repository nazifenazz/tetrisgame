public abstract class HareketSekilleri {
    public int satir = 0;
    public int sutun = 4;


    public abstract int[][] hucreler();

    public abstract void sekliCiz(int[][] dizi);
    public abstract void sekliSil(int[][] dizi);
    public abstract void dondur(int[][] dizi);
    public abstract boolean altDoluMu(int[][] dizi);


    public int getDurum() { return 0; }
    public void setDurum(int d) { }

    public void asagiGit() { satir++; }
}


















