public class Kare extends HareketSekilleri {

    @Override
    public int[][] hucreler() {
        return new int[][]{
                {satir, sutun}, {satir, sutun+1},
                {satir+1, sutun}, {satir+1, sutun+1}
        };
    }

    @Override
    public void sekliCiz(int[][] dizi) {
        dizi[satir][sutun] = 1; dizi[satir][sutun+1] = 1;
        dizi[satir+1][sutun] = 1; dizi[satir+1][sutun+1] = 1;
    }

    @Override
    public void sekliSil(int[][] dizi) {
        dizi[satir][sutun] = 0; dizi[satir][sutun+1] = 0;
        dizi[satir+1][sutun] = 0; dizi[satir+1][sutun+1] = 0;
    }

    @Override public void dondur(int[][] dizi) { }

    @Override
    public boolean altDoluMu(int[][] dizi) {
        return false;
    }
}
