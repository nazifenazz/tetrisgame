public class SatirSil {

    public void satirSilme(int[][] dizi) {
        // En alttan başlayarak her satırı kontrol ediyoruz
        for (int i = 19; i >= 0; i--) {
            boolean satirDolu = true;

            // Satırda hiç boş yer  var mı bakıyoruz
            for (int j = 0; j < 11; j++) {
                if (dizi[i][j] == 0) {
                    satirDolu = false;
                    break;
                }
            }


            if (satirDolu) {
                //  O.satırı tamamen siliyoruz
                for (int j = 0; j < 11; j++) {
                    dizi[i][j] = 0;
                }

                // Üstteki satırları bir aşağı indiriyoruz
                for (int k = i; k > 0; k--) {
                    for (int j = 0; j < 11; j++) {
                        dizi[k][j] = dizi[k - 1][j];
                    }
                }

                // En üst satırı temizliyoz
                for (int j = 0; j < 11; j++) {
                    dizi[0][j] = 0;
                }


                // üst satır artık alt satır oldugu için i++
                i++;
            }
        }
    }
}