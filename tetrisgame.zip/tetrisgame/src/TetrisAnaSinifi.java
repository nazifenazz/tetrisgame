import java.io.IOException;

public class TetrisAnaSinifi {
    public static void main() throws InterruptedException, IOException {
        Tetris oyun1 = new Tetris();
        oyun1.metotBaslat();
    }
}
