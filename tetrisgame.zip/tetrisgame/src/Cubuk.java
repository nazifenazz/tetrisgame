public class Cubuk extends HareketSekilleri {
    private int durum = 0; // 0 Dikey 1Yatay

    @Override public int getDurum() { return durum; }
    @Override public void setDurum(int d) { durum = d; }

    @Override
    public int[][] hucreler() {
        if (durum == 0) {
            return new int[][]{
                    {satir, sutun},
                    {satir+1, sutun},
                    {satir+2, sutun},
                    {satir+3, sutun}
            };
        } else {
            return new int[][]{
                    {satir, sutun},
                    {satir, sutun+1},
                    {satir, sutun+2},
                    {satir, sutun+3}
            };
        }
    }

    @Override
    public void sekliCiz(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 1;
    }

    @Override
    public void sekliSil(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 0;
    }

    @Override
    public void dondur(int[][] dizi) {
        durum = (durum + 1) % 2;
    }

    @Override
    public boolean altDoluMu(int[][] dizi) {
        return false;
    }
}
