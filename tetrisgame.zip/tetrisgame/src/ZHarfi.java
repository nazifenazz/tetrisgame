public class ZHarfi extends HareketSekilleri {
    private int durum = 0; // 0 Yatay 1 Dikey Z

    @Override public int getDurum() { return durum; }
    @Override public void setDurum(int d) { durum = d; }

    @Override
    public int[][] hucreler() {
        if (durum == 0) { //normal z
            return new int[][]{
                    {satir, sutun}, {satir, sutun+1},
                    {satir+1, sutun+1}, {satir+1, sutun+2}
            };
        } else {
            return new int[][]{
                    {satir, sutun+1},
                    {satir+1, sutun+1},
                    {satir+1, sutun},
                    {satir+2, sutun}
            };
        }
    }

    @Override
    public void sekliCiz(int[][] dizi) {//hücrelerden gelen yerleri 1 yapar
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 1;
    }

    @Override
    public void sekliSil(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 0;
    }

    @Override
    public void dondur(int[][] dizi) {
        durum = (durum + 1) % 2;
    }

    @Override
    public boolean altDoluMu(int[][] dizi) {

        return false;
    }
}
