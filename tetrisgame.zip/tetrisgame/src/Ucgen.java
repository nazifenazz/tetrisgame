public class Ucgen extends HareketSekilleri {
    private int durum = 0; // 0-1-2-3 yönleri var

    @Override public int getDurum() { return durum; }
    @Override public void setDurum(int d) { durum = d; }

    @Override
    public int[][] hucreler() {



        if (durum == 0) {  //normal hali
            return new int[][]{
                    {satir, sutun+1},
                    {satir+1, sutun},
                    {satir+1, sutun+1},
                    {satir+1, sutun+2}
            };
        } else if (durum == 1) {//90 derece dönmüş hali
            return new int[][]{
                    {satir, sutun},
                    {satir+1, sutun},
                    {satir+1, sutun+1},
                    {satir+2, sutun}
            };
        } else if (durum == 2) {//ters
            return new int[][]{
                    {satir, sutun},
                    {satir, sutun+1},
                    {satir, sutun+2},
                    {satir+1, sutun+1}
            };
        } else { //diğer tarafa dönmüş hali
            return new int[][]{
                    {satir, sutun+1},
                    {satir+1, sutun},
                    {satir+1, sutun+1},
                    {satir+2, sutun+1}
            };
        }
    }

    @Override
    public void sekliCiz(int[][] dizi) {//şeklin koordinatlarına 1 yazıyor
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 1;
    }

    @Override
    public void sekliSil(int[][] dizi) {
        int[][] h = hucreler();
        for (int i=0; i<4; i++) dizi[h[i][0]][h[i][1]] = 0;
    }

    @Override
    public void dondur(int[][] dizi) {
        durum = (durum + 1) % 4;
    }

    @Override
    public boolean altDoluMu(int[][] dizi) {

        return false;
    }
}
